# Custom Keyboard for Android

A minimal but fully working custom keyboard (IME) app. QWERTY layout, shift, backspace,
space, enter, and a symbols page (?123 <-> ABC toggle).

## What's included
- `MyKeyboardService.java` – the keyboard engine (InputMethodService)
- `SettingsActivity.java` – launcher screen with buttons to enable/switch the keyboard
- `res/xml/qwerty.xml` / `symbols.xml` – key layouts
- `res/xml/method.xml` – IME registration metadata
- `res/layout/keyboard_view.xml` – the KeyboardView UI
- `AndroidManifest.xml` – registers the IME service

## How to build

1. Install **Android Studio** (free, from developer.android.com).
2. Open this project folder (`CustomKeyboard/`) in Android Studio: File > Open.
3. Let Gradle sync (it will download dependencies automatically — needs internet).
4. Connect your Infinix Hot 30i via USB with **USB debugging** enabled
   (Settings > About phone > tap Build number 7x > Developer options > USB debugging),
   or use an emulator.
5. Click **Run ▶** in Android Studio. This installs the app on your phone.

## How to enable it on your phone

1. Open the installed app ("My Custom Keyboard") — it has two buttons.
2. Tap **"Enable Keyboard (System Settings)"** → toggle your new keyboard ON in the list.
3. Open any app with a text field (e.g. Messages), tap the field to bring up a keyboard.
4. Tap **"Switch Keyboard Now"** in the app, or long-press the spacebar / tap the
   keyboard-switch icon in the notification bar, and pick "My Custom Keyboard".

## Customize it further
- **Colors/theme**: edit `res/drawable/key_background.xml` and `keyboard_view.xml`.
- **Key layout**: edit `res/xml/qwerty.xml` — each `<Key>` has a `codes` (ASCII value),
  `keyLabel`, and `keyWidth`.
- **Add number row**: duplicate a `<Row>` block in `qwerty.xml`.
- **Autocorrect / word suggestions**: this is the hard part — you'd add a candidate
  strip above the keyboard and hook it to a dictionary or a library. Ask me if you want
  this built out next.
- **Swipe typing**: requires gesture-path recognition — a bigger project on top of this base.

## Notes
- Minimum Android version supported: Android 5.0 (API 21) — fine for the Hot 30i (Android 13).
- No internet permission is requested, so this keyboard cannot leak anything typed —
  good practice to keep it that way unless you deliberately add a feature needing it.
