package com.example.customkeyboard;

import android.os.Bundle;
import android.provider.Settings;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 80, 40, 40);

        TextView info = new TextView(this);
        info.setText("Step 1: Enable this keyboard in system settings.\n\n" +
                "Step 2: Switch to it from your input method picker while typing.");
        info.setTextSize(16);
        layout.addView(info);

        Button enableBtn = new Button(this);
        enableBtn.setText("Enable Keyboard (System Settings)");
        enableBtn.setOnClickListener(v ->
                startActivity(new android.content.Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        layout.addView(enableBtn);

        Button switchBtn = new Button(this);
        switchBtn.setText("Switch Keyboard Now");
        switchBtn.setOnClickListener(v -> {
            InputMethodManager imm =
                    (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        });
        layout.addView(switchBtn);

        setContentView(layout);
    }
}
