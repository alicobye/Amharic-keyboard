package com.example.customkeyboard;

import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

public class MyKeyboardService extends InputMethodService
        implements KeyboardView.OnKeyboardActionListener {

    private KeyboardView keyboardView;
    private Keyboard qwertyKeyboard;
    private Keyboard symbolsKeyboard;
    private boolean isShifted = false;
    private boolean isSymbols = false;

    @Override
    public View onCreateInputView() {
        keyboardView = (KeyboardView) getLayoutInflater()
                .inflate(R.layout.keyboard_view, null);

        qwertyKeyboard = new Keyboard(this, R.xml.qwerty);
        symbolsKeyboard = new Keyboard(this, R.xml.symbols);

        keyboardView.setKeyboard(qwertyKeyboard);
        keyboardView.setOnKeyboardActionListener(this);

        return keyboardView;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        isSymbols = false;
        isShifted = false;
        keyboardView.setKeyboard(qwertyKeyboard);
        keyboardView.setShifted(false);
    }

    @Override
    public void onKey(int primaryCode, int[] keyCodes) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        switch (primaryCode) {
            case Keyboard.KEYCODE_DELETE: // -5
                ic.deleteSurroundingText(1, 0);
                break;

            case Keyboard.KEYCODE_SHIFT: // -1
                isShifted = !isShifted;
                qwertyKeyboard.setShifted(isShifted);
                keyboardView.invalidateAllKeys();
                break;

            case Keyboard.KEYCODE_MODE_CHANGE: // -2
                isSymbols = !isSymbols;
                keyboardView.setKeyboard(isSymbols ? symbolsKeyboard : qwertyKeyboard);
                break;

            case Keyboard.KEYCODE_DONE: // -4
                ic.sendKeyEvent(new android.view.KeyEvent(
                        android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER));
                ic.sendKeyEvent(new android.view.KeyEvent(
                        android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_ENTER));
                break;

            default:
                char code = (char) primaryCode;
                if (Character.isLetter(code) && isShifted) {
                    code = Character.toUpperCase(code);
                    // Auto-unshift after one character (like most keyboards)
                    isShifted = false;
                    qwertyKeyboard.setShifted(false);
                    keyboardView.invalidateAllKeys();
                }
                ic.commitText(String.valueOf(code), 1);
        }
    }

    // --- Required but unused callbacks for OnKeyboardActionListener ---
    @Override public void onPress(int primaryCode) {}
    @Override public void onRelease(int primaryCode) {}
    @Override public void onText(CharSequence text) {}
    @Override public void swipeLeft() {}
    @Override public void swipeRight() {}
    @Override public void swipeDown() {}
    @Override public void swipeUp() {}
}
